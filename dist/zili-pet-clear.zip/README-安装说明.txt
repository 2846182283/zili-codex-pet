﻿紫璃 · 小尺寸清晰版

需要支持自定义宠物的 Codex 桌面客户端。

1. 解压后，找到包含 pet.json 和 spritesheet.webp 的 zili 文件夹。
2. Windows：将 zili 放入 %USERPROFILE%\.codex\pets。缺少目录时，进入 %USERPROFILE%，依次新建 .codex 和 pets 文件夹。
   macOS：先在终端运行 mkdir -p ~/.codex/pets 创建所需目录，再将 zili 放入 ~/.codex/pets（本次未进行 macOS 实机验证）。
   如自定义了 CODEX_HOME，使用其 pets 目录。
3. 已有同名 zili 时先备份，再替换。
4. 回到 Codex 设置中的宠物页面，刷新资源列表、选择紫璃并打开显示。界面名称以实际版本为准。

正确层级：
pets/
  zili/
    pet.json
    spritesheet.webp

不要多套一层 zili，不要改两份文件的名称。previews 仅供预览，无需安装。
若仍显示旧版，可刷新后重新选择紫璃，或隐藏后重新显示，再检查实际外观。

本资源为非官方、AI辅助制作。来源和许可状态见 CREDITS.md。
